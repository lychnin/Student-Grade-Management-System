package dao;

import model.Admin;
import view.IndexFrame;

import java.sql.ResultSet;
import java.sql.SQLException;

import static view.IndexFrame.admin;

// Methods for the Administrator
public class AdminDao extends BaseDao {
    // Login screen selection for Administrator identity
    public Admin selectAdmin(String name, String password) {
        String sqlStr = "SELECT * FROM adminLogin WHERE name = ? AND password = ?";
        Admin admin = null;
        try {
            this.pStatement = this.con.prepareStatement(sqlStr);
            this.pStatement.setString(1, name);
            this.pStatement.setString(2, password);

            ResultSet executeQuery = this.pStatement.executeQuery();
            if (executeQuery.next()) {
                admin = new Admin(
                        executeQuery.getInt(1),
                        executeQuery.getString(2),
                        executeQuery.getString(3)
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.close();
        }
        return admin;
    }

    // Administrator changes password
    public String revisePassword(String name, String newPassword) {
        String resultStr = "Operation failed";
        String sqlStr = "UPDATE adminLogin SET password = ? WHERE name = ? AND password = ?";
        try {
            this.pStatement = this.con.prepareStatement(sqlStr);
            this.pStatement.setString(1, newPassword);
            this.pStatement.setString(2, admin.getName());
            this.pStatement.setString(3, admin.getPassword());
            if (pStatement.executeUpdate() > 0) {
                resultStr = "Operation successful!";
                IndexFrame.admin.setPassword(newPassword);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.close();
        }
        return resultStr;
    }
}
