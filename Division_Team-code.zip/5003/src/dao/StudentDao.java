package dao;

import model.Student;
import view.IndexFrame;
import view.StudentFrame;

import javax.swing.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static view.StudentFrame.student;


public class StudentDao extends BaseDao{
    public Student selectStudent(String name, String password){
        String sqlStr = "select * from studentLogin where name = ? and password = ?";
        Student student = null;
        try{
            this.pStatement = this.con.prepareStatement(sqlStr);
            this.pStatement.setString(1,name);
            this.pStatement.setString(2,password);

            ResultSet executeQuery = this.pStatement.executeQuery();
            if(executeQuery.next()){
                student = new Student(executeQuery.getInt(1),executeQuery.getString(2),executeQuery.getString(3));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            this.close();
        }
        return student;
    }

    public String revisePassword(String name,String newPassword){
        String resultStr = "Faliure";

        String sqlStr = "update studentLogin set password = ? where name = ? and password = ?";
        try{
            this.pStatement = this.con.prepareStatement(sqlStr);
            this.pStatement.setString(1,newPassword);
            this.pStatement.setString(2,student.getName());
            this.pStatement.setString(3, student.getPassword());
            if(pStatement.executeUpdate()>0){
                resultStr = "Success";

                StudentFrame.student.setPassword(newPassword);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            this.close();
        }
        return resultStr;
    }
    public String addStuLogin(String id,String name,String password) {
        String resultStr = "Faliure";
        String sqlStr = "insert into studentLogin values(?,?,?)";
        try {
            this.pStatement = this.con.prepareStatement(sqlStr);
            this.pStatement.setString(1, id);
            this.pStatement.setString(2, name);
            this.pStatement.setString(3, password);
            if(pStatement.executeUpdate()>0) {

                String sqlStr1 = "insert into student values(?,?,null,null,null)";
                PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr1);
                preparedStatement.setInt(1, Integer.parseInt(id));
                preparedStatement.setString(2,name);
                if(preparedStatement.executeUpdate()>=1){
                    resultStr = "Success";
                }


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            this.close();
        }
        return resultStr;
    }

    public String deleteStuInfo(String StuName,int StuID) throws SQLException {
        String resultStr = "Delete Faliure";
        String sqlStr1 = "delete from chooseCourse where studentName = ? and studentId = ?";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr1);
        preparedStatement.setString(1,StuName);
        preparedStatement.setInt(2,StuID);
        if(preparedStatement.executeUpdate()>=0){
            String sqlStr2 = "delete from student where name = ? and id = ?";
            PreparedStatement p = this.con.prepareStatement(sqlStr2);
            p.setString(1,StuName);
            p.setInt(2,StuID);
            if(p.executeUpdate()>=1){
                String sqlStr3 = "delete from studentLogin where name = ? and id = ?";
                PreparedStatement preparedStatement1 = this.con.prepareStatement(sqlStr3);
                preparedStatement1.setString(1,StuName);
                preparedStatement1.setInt(2,StuID);
                if(preparedStatement1.executeUpdate()>=1){
                    resultStr = "Delete Success";
                }
            }
        }
        return resultStr;
    }


    public String reviseStuInfo(String ChangeWho,String StuSex,int StuAge,String StuDept,String StuPassword) throws SQLException {
        String resultStr = "Modify Faliure";
        String sqlStr = "update student set  sex = ? , age = ? , dept = ? where name = ?";

        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);

        preparedStatement.setString(1,StuSex);
        preparedStatement.setInt(2,StuAge);
        preparedStatement.setString(3,StuDept);
        preparedStatement.setString(4,ChangeWho);
        if(preparedStatement.executeUpdate()>=0&&StuPassword==null){
            resultStr = "Modify Success";
        }
        if(StuPassword!=null){
            String sqlStr1 = "update studentLogin set password = ? where name = ?";
            PreparedStatement preparedStatement1 = this.con.prepareStatement(sqlStr1);
            preparedStatement1.setString(1,StuPassword);
            preparedStatement1.setString(2,ChangeWho);
            if(preparedStatement1.executeUpdate()>=1){
                resultStr = "Modify Success";
            }
        }
        return resultStr;
    }

    public String getId(String name) throws SQLException {
        String resultStr = null;
        String sqlStr = "select id from student where name = ? ";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,name);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            resultStr = resultSet.getString("id");
        }
        System.out.println(resultStr);
        return resultStr;
    }
    public String getDept(String name) throws SQLException {
        String resultStr = null;
        String sqlStr = "select dept from student where name = ?";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,name);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            resultStr = resultSet.getString("dept");
        }
        return resultStr;
    }
    public String getAge(String name) throws SQLException {
        String resultAge = null;
        String sqlStr = "select age from student where name = ?";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,name);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            resultAge = resultSet.getString("age");
        }
        return resultAge;
    }
    public String getSex(String name) throws SQLException {
        String resultSex = null;
        String sqlStr = "select sex from student where name = ?";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,name);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            resultSex = resultSet.getString("sex");
        }
        return resultSex;
    }

    public int FindGrade(String studentName,String courseName) throws SQLException {
        String resultStr = null;
        int result = 0;
        String sqlStr = "select grade from chooseCourse where studentName = ? and courseName = ?";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,studentName);
        preparedStatement.setString(2,courseName);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            resultStr = resultSet.getString("grade");
            result = resultSet.getInt("grade");
        }
        return result;
    }

    public String ChooseCourse(String stuID,String stuName,String courseID , String courseName) throws SQLException {
        String resultStr = "Course Registration Faliure";
        String sqlStr = "insert into chooseCourse values(?,?,?,?,null)";
        PreparedStatement preparedStatement = this.con.prepareStatement(sqlStr);
        preparedStatement.setString(1,stuID);
        preparedStatement.setString(2,stuName);
        preparedStatement.setString(3,courseID);
        preparedStatement.setString(4,courseName);
        if(preparedStatement.executeUpdate()>=1){
            resultStr = "Course Registeration Success";
        }
        return resultStr;
    }

}
