package model;

// Administrator class
public class Admin {
    private int id;
    private String name;
    private String password;

    // Default constructor
    public Admin() {

    }



    // Constructor with name and password
    public Admin(String name, String password) {
        this.name = name;
        this.password = password;
    }

    // Constructor with id, name, and password
    public Admin(int id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }

    // Getter for id
    public int getId() {
        return id;
    }

    // Setter for id
    public void setId(int id) {
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }

    // toString method to represent the object as a string
    public String toString() {
        return name + " " + password;
    }
}
