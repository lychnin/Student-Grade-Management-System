package model;
// Enum class, user type
public enum UserType {
    ADMIN("System Administrator", 0),
    STUDENT("Student", 1),
    TEACHER("Teacher", 2);
    private String name;
    private int index;
    private UserType(String name, int index) {
        this.name = name;
        this.index = index;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
    public String toString() {
        return name;
    }
}
