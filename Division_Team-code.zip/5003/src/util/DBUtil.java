package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBUtil {
    private static final Logger logger = Logger.getLogger(DBUtil.class.getName());
    private static final String JDBC_DRIVER = "org.sqlite.JDBC";
    private static String dbUrl; // Database URL is now dynamic
    private static Connection connection = null;

    /**
     * Initialize the database URL. This must be called before using getConnection().
     *
     * @param dbPath Path to the SQLite database file.
     */
    public static synchronized void initialize(String dbPath) {
        dbUrl = "jdbc:sqlite:" + dbPath;
        logger.info("Database URL initialized: " + dbUrl);
    }

    /**
     * Get the database connection (singleton pattern).
     *
     * @return Connection instance
     */
    public static synchronized Connection getConnection() {
        if (connection == null || isConnectionClosed(connection)) {
            try {
                if (dbUrl == null || dbUrl.isEmpty()) {
                    throw new IllegalStateException("Database URL is not initialized. Call initialize() first.");
                }
                Class.forName(JDBC_DRIVER);
                connection = DriverManager.getConnection(dbUrl);
                logger.info("Database connected successfully.");
            } catch (ClassNotFoundException e) {
                logger.log(Level.SEVERE, "SQLite JDBC Driver not found. Ensure the driver is in the classpath.", e);
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Failed to connect to the database. Please check the database path.", e);
            }
        }
        return connection;
    }

    /**
     * Check if the connection is closed.
     *
     * @param conn Database connection
     * @return Whether the connection is closed
     */
    private static boolean isConnectionClosed(Connection conn) {
        try {
            return conn == null || conn.isClosed();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error while checking if the connection is closed.", e);
            return true;
        }
    }

    /**
     * Close the global singleton connection (should be called at the end of the application lifecycle).
     */
    public static synchronized void closeGlobalConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                logger.info("Database connection closed.");
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Failed to close the database connection.", e);
            }
        }
    }
}
