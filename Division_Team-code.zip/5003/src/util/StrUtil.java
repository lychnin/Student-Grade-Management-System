package util;
public class StrUtil {
    public static boolean isEmpty(String str){
        return "".equals(str) || str == null;
    }
}
