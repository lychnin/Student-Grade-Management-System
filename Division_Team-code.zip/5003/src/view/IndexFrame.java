package view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Admin;
import model.UserType;
import view.systemManager.*;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import java.awt.Color;

public class IndexFrame extends JFrame {

    private JPanel contentPane;
    private JDesktopPane desktopPane;
    public static UserType userType;
    public static Admin admin;

    /**
     * Launch the application.
     */

    /**
     * Create the frame.
     */
    public IndexFrame(UserType u, Admin a) {
        userType = u;
        admin = a;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1001, 701);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu mnNewMenu = new JMenu("Manage System");
        mnNewMenu.setFont(new Font("Arial", Font.BOLD, 15));
        menuBar.add(mnNewMenu);

        JMenuItem mntmNewMenuItem = new JMenuItem("Modify Password");
        mntmNewMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                revisePassword(e);
            }
        });
        mntmNewMenuItem.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu.add(mntmNewMenuItem);

        JMenuItem mntmNewMenuItem_1 = new JMenuItem("Exit System");
        mntmNewMenuItem_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        mntmNewMenuItem_1.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu.add(mntmNewMenuItem_1);

        JMenu mnNewMenu_1 = new JMenu("Manage Teacher");
        mnNewMenu_1.setFont(new Font("Arial", Font.BOLD, 15));
        menuBar.add(mnNewMenu_1);

        JMenuItem mntmNewMenuItem_2 = new JMenuItem("Add Teacher");
        mntmNewMenuItem_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addNewTeacher(e);
            }
        });
        mntmNewMenuItem_2.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_1.add(mntmNewMenuItem_2);

        JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("Delete Teacher");
        mntmNewMenuItem_1_1.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_1.add(mntmNewMenuItem_1_1);

        JMenuItem mntmNewMenuItem_1_1_1 = new JMenuItem("Modify Teacher");
        mntmNewMenuItem_1_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reviseTeacher(e);
            }
        });
        mntmNewMenuItem_1_1_1.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_1.add(mntmNewMenuItem_1_1_1);

        JMenuItem mntmNewMenuItem_1_1_2 = new JMenuItem("Inquire Teacher");
        mntmNewMenuItem_1_1_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findTeacher(e);
            }
        });
        mntmNewMenuItem_1_1_2.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_1.add(mntmNewMenuItem_1_1_2);

        JMenu mnNewMenu_2 = new JMenu("Manage Student");
        mnNewMenu_2.setFont(new Font("Arial", Font.BOLD, 15));
        menuBar.add(mnNewMenu_2);

        JMenuItem mntmNewMenuItem_3 = new JMenuItem("Add Student");
        mntmNewMenuItem_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addNewStu(e);
            }
        });
        mntmNewMenuItem_3.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_2.add(mntmNewMenuItem_3);

        JMenuItem mntmNewMenuItem_1_2 = new JMenuItem("Delete Student");
        mntmNewMenuItem_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteTeacher(e);
            }
        });
        mntmNewMenuItem_1_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteStu(e);
            }
        });
        mntmNewMenuItem_1_2.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_2.add(mntmNewMenuItem_1_2);

        JMenuItem mntmNewMenuItem_1_2_1 = new JMenuItem("Modify Student");
        mntmNewMenuItem_1_2_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                changeStuInfo(e);
            }
        });
        mntmNewMenuItem_1_2_1.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_2.add(mntmNewMenuItem_1_2_1);

        JMenuItem mntmNewMenuItem_1_2_2 = new JMenuItem("Inquire Student");
        mntmNewMenuItem_1_2_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findStuInfo(e);
            }
        });
        mntmNewMenuItem_1_2_2.setFont(new Font("Arial", Font.BOLD, 14));
        mnNewMenu_2.add(mntmNewMenuItem_1_2_2);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);

        desktopPane = new JDesktopPane();
        desktopPane.setBackground(new Color(173, 216, 230));
        contentPane.add(desktopPane, BorderLayout.CENTER);
    }

    private void exitButton(ActionEvent e) {
        this.setVisible(false);
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }

    protected void addNewTeacher(ActionEvent e) {
        AddTeacherFrame addTeacherFrame = new AddTeacherFrame();
        addTeacherFrame.setVisible(true);
    }

    protected void deleteTeacher(ActionEvent e) {
        DeleteTeacherInfoFrame deleteTeacherInfoFrame = new DeleteTeacherInfoFrame();
        deleteTeacherInfoFrame.setVisible(true);
    }

    protected void reviseTeacher(ActionEvent e) {
        ReviseTeacherInfoFrame reviseTeacherInfoFrame = new ReviseTeacherInfoFrame();
        reviseTeacherInfoFrame.setVisible(true);
    }

    protected void findTeacher(ActionEvent e) {
        FindTeacherInfoFrame findTeacherInfoFrame = new FindTeacherInfoFrame();
        findTeacherInfoFrame.setVisible(true);
    }

    protected void addNewStu(ActionEvent e) {
        AddStudentFrame addStudentFrame = new AddStudentFrame();
        addStudentFrame.setVisible(true);
    }

    protected void deleteStu(ActionEvent e) {
        DeleteStuInfoFrame deleteStuInfoFrame = new DeleteStuInfoFrame();
        deleteStuInfoFrame.setVisible(true);
    }

    protected void changeStuInfo(ActionEvent e) {
        ReviseStuInfoFrame reviseStuInfoFrame = new ReviseStuInfoFrame();
        reviseStuInfoFrame.setVisible(true);
    }

    protected void findStuInfo(ActionEvent e) {
        FindStuInfoFrame findStuInfoFrame = new FindStuInfoFrame();
        findStuInfoFrame.setVisible(true);
    }

    private void revisePassword(ActionEvent e) {
        desktopPane.add(new RevisePassword());
    }

}
