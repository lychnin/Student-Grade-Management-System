package view;

import dao.AdminDao;
import dao.StudentDao;
import dao.TeacherDao;
import model.Admin;
import model.Student;
import model.Teacher;
import model.UserType;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Main Login Interface
 */
public class LoginFrame extends JFrame {

    private JPanel contentPane;
    private JTextField adminName;
    private JPasswordField adminPassword;
    private JComboBox adminTypeComb;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        // Check if the database path is provided as a command-line argument
        if (args.length < 1) {
            System.err.println("Usage: java -jar StudentInformationManagementSystem.jar <path-to-your-local-db-file>");
            System.exit(1);
        }

        // Initialize the database connection
        String dbPath = args[0];
        util.DBUtil.initialize(dbPath);

        // Launch the GUI
        EventQueue.invokeLater(() -> {
            try {
                LoginFrame frame = new LoginFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    /**
     * Create the frame.
     */
    public LoginFrame() {
        setTitle("Login Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 400); // Adjusted frame size
        setLocationRelativeTo(null);

        // Content Pane with padding and custom layout
        contentPane = new JPanel();
        contentPane.setBackground(new Color(240, 248, 255)); // Light blue background
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Header Label
        JLabel lblNewLabel = new JLabel("Student Information Management System");
        lblNewLabel.setForeground(new Color(25, 25, 112)); // Navy Blue
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 20));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(30, 10, 440, 40);
        contentPane.add(lblNewLabel);

        // User Name Label
        JLabel lblNewLabel_1 = new JLabel("User Name:");
        lblNewLabel_1.setForeground(new Color(0, 102, 204)); // Medium blue
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(100, 90, 100, 25);
        contentPane.add(lblNewLabel_1);

        // Password Label
        JLabel lblNewLabel_2 = new JLabel("Password:");
        lblNewLabel_2.setForeground(new Color(0, 102, 204));
        lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_2.setBounds(100, 140, 100, 25);
        contentPane.add(lblNewLabel_2);

        // User Class Label
        JLabel lblNewLabel_3 = new JLabel("User Class:");
        lblNewLabel_3.setForeground(new Color(0, 102, 204));
        lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_3.setBounds(100, 190, 100, 25);
        contentPane.add(lblNewLabel_3);

        // Input Field for Username
        adminName = new JTextField();
        adminName.setFont(new Font("Arial", Font.PLAIN, 14));
        adminName.setBounds(200, 90, 180, 25);
        contentPane.add(adminName);
        adminName.setColumns(10);

        // Password Field
        adminPassword = new JPasswordField();
        adminPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        adminPassword.setBounds(200, 140, 180, 25);
        contentPane.add(adminPassword);
        adminPassword.setColumns(10);

        // User Type Combo Box
        adminTypeComb = new JComboBox();
        adminTypeComb.setFont(new Font("Arial", Font.PLAIN, 14));
        adminTypeComb.setModel(new DefaultComboBoxModel(new UserType[]{UserType.ADMIN, UserType.STUDENT, UserType.TEACHER}));
        adminTypeComb.setBounds(200, 190, 180, 25);
        contentPane.add(adminTypeComb);

        // Reset Button
        JButton btnNewButton = new JButton("Reset");
        btnNewButton.setFont(new Font("Arial", Font.BOLD, 14));
        btnNewButton.setBackground(new Color(220, 220, 220));
        btnNewButton.setForeground(new Color(0, 102, 204));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        btnNewButton.setBounds(260, 260, 120, 30);
        contentPane.add(btnNewButton);

        // Login Button
        JButton btnNewButton_1 = new JButton("Log in");
        btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 14));
        btnNewButton_1.setBackground(new Color(220, 220, 220)); // Dodger blue
        btnNewButton_1.setForeground(new Color(0, 102, 204));
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                confirmLoginButton(e);
            }
        });
        btnNewButton_1.setBounds(100, 260, 120, 30);
        contentPane.add(btnNewButton_1);
    }

    /**
     * Confirm login action listener.
     */
    protected void confirmLoginButton(ActionEvent e) {
        String name = this.adminName.getText();
        String password = new String(this.adminPassword.getPassword());
        UserType userType = (UserType) this.adminTypeComb.getSelectedItem();

        if ("System Administrator".equals(userType.getName())) {
            AdminDao adminDao = new AdminDao();
            Admin admin = adminDao.selectAdmin(name, password);
            if (admin == null) {
                JOptionPane.showMessageDialog(this, "Wrong username or password");
            } else {
                JOptionPane.showMessageDialog(this, "Login successful");
                IndexFrame indexFrame = new IndexFrame(userType, admin);
                indexFrame.setVisible(true);
                this.dispose();
            }
        }
        if ("Student".equals(userType.getName())) {
            StudentDao studentDao = new StudentDao();
            Student student = studentDao.selectStudent(name, password);
            if (student == null) {
                JOptionPane.showMessageDialog(this, "Wrong username or password");
            } else {
                JOptionPane.showMessageDialog(this, "Login successful");
                StudentFrame studentFrame = new StudentFrame(userType, student);
                studentFrame.setVisible(true);
                this.dispose();
            }
        }
        if ("Teacher".equals(userType.getName())) {
            TeacherDao teacherDao = new TeacherDao();
            Teacher teacher = teacherDao.selectTeacher(name, password);
            if (teacher == null) {
                JOptionPane.showMessageDialog(this, "Wrong username or password");
            } else {
                JOptionPane.showMessageDialog(this, "Login successful");
                TeacherFrame teacherFrame = new TeacherFrame(userType, teacher);
                teacherFrame.setVisible(true);
                this.dispose();
            }
        }
    }

    /**
     * Reset action listener. Resets all input fields.
     */
    private void resetButton(ActionEvent e) {
        this.adminName.setText("");
        this.adminPassword.setText("");
        this.adminTypeComb.setSelectedIndex(0);
    }
}
