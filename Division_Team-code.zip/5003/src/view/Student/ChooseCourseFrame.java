package view.Student;

import dao.StudentDao;
import view.StudentFrame;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class ChooseCourseFrame extends JFrame {

    private JPanel contentPane;
    private JTextField ChooseCourseName;
    private JTextField ChooseCourseID;
    private JButton btnRegister;
    private JButton btnReset;
    private JButton btnExit;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ChooseCourseFrame frame = new ChooseCourseFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public ChooseCourseFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Adjusted window size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Course Registration");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setBounds(150, 20, 250, 30);
        contentPane.add(lblTitle);

        JLabel lblCourseName = new JLabel("Course Name:");
        lblCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        lblCourseName.setBounds(60, 80, 150, 30);
        contentPane.add(lblCourseName);

        ChooseCourseName = new JTextField();
        ChooseCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        ChooseCourseName.setBounds(200, 80, 220, 30);
        contentPane.add(ChooseCourseName);

        JLabel lblCourseID = new JLabel("Course ID:");
        lblCourseID.setFont(new Font("Arial", Font.PLAIN, 16));
        lblCourseID.setBounds(60, 130, 150, 30);
        contentPane.add(lblCourseID);

        ChooseCourseID = new JTextField();
        ChooseCourseID.setFont(new Font("Arial", Font.PLAIN, 16));
        ChooseCourseID.setBounds(200, 130, 220, 30);
        contentPane.add(ChooseCourseID);

        btnRegister = new JButton("Register");
        btnRegister.setFont(new Font("Arial", Font.PLAIN, 16));
        btnRegister.setBounds(60, 220, 120, 40);
        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    chooseCourse(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnRegister);

        btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(190, 220, 120, 40);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnReset);

        btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(320, 220, 120, 40);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExit);
    }

    protected void chooseCourse(ActionEvent e) throws SQLException {
        // Handle course registration
        StudentDao sd = new StudentDao();
        String courseID = this.ChooseCourseID.getText();
        String courseName = this.ChooseCourseName.getText();
        String studentID = sd.getId(StudentFrame.student.getName());
        String studentName = StudentFrame.student.getName();

        String result = sd.ChooseCourse(studentID, studentName, courseID, courseName);
        JOptionPane.showMessageDialog(this, result);

        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        // Reset input fields
        this.ChooseCourseID.setText("");
        this.ChooseCourseName.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Close the window
        this.dispose();
    }
}
