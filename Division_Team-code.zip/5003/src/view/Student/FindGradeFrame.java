package view.Student;

import dao.StudentDao;
import view.StudentFrame;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class FindGradeFrame extends JFrame {

    private JPanel contentPane;
    private JTextField FindCourseName;
    private JTextField GradeField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                FindGradeFrame frame = new FindGradeFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public FindGradeFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Adjusted window size for better layout
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Find Course Grade");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setBounds(140, 20, 300, 30);
        contentPane.add(lblTitle);

        JLabel lblCourseName = new JLabel("Course Name:");
        lblCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        lblCourseName.setBounds(50, 80, 120, 30);
        contentPane.add(lblCourseName);

        FindCourseName = new JTextField();
        FindCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        FindCourseName.setBounds(200, 80, 220, 30);
        contentPane.add(FindCourseName);
        FindCourseName.setColumns(10);

        JLabel lblGrade = new JLabel("Your Grade:");
        lblGrade.setFont(new Font("Arial", Font.PLAIN, 16));
        lblGrade.setBounds(50, 140, 120, 30);
        contentPane.add(lblGrade);

        GradeField = new JTextField();
        GradeField.setFont(new Font("Arial", Font.PLAIN, 16));
        GradeField.setEditable(false); // Make the field non-editable
        GradeField.setBounds(200, 140, 220, 30);
        contentPane.add(GradeField);
        GradeField.setColumns(10);

        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Arial", Font.PLAIN, 16));
        btnSearch.setBounds(50, 220, 120, 40);
        btnSearch.addActionListener(e -> {
            try {
                findCourse(e);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
        contentPane.add(btnSearch);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(190, 220, 120, 40);
        btnReset.addActionListener(this::resetButton);
        contentPane.add(btnReset);

        JButton btnClose = new JButton("Close");
        btnClose.setFont(new Font("Arial", Font.PLAIN, 16));
        btnClose.setBounds(330, 220, 120, 40);
        btnClose.addActionListener(this::closeButton);
        contentPane.add(btnClose);
    }

    private void findCourse(ActionEvent e) throws SQLException {
        String courseName = FindCourseName.getText();
        if (courseName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a course name.");
            return;
        }

        StudentDao studentDao = new StudentDao();
        String studentName = StudentFrame.student.getName();
        int grade = studentDao.FindGrade(studentName, courseName);

        // Display the grade in the grade field
        GradeField.setText(grade > 0 ? String.valueOf(grade) : "N/A");

        // Notify if no grade is found
        if (grade == 0) {
            JOptionPane.showMessageDialog(this, "You haven't registered for this course or the grade is not released.");
        }
    }

    protected void resetButton(ActionEvent e) {
        // Clear input fields
        FindCourseName.setText("");
        GradeField.setText("");
    }

    protected void closeButton(ActionEvent e) {
        // Close the window
        this.dispose();
    }
}
