package view.Student;

import dao.AdminDao;
import dao.StudentDao;
import dao.TeacherDao;
import util.StrUtil;
import view.IndexFrame;
import view.StudentFrame;
import view.TeacherFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class RevisePassword extends JFrame {
    private JTextField oldPasswordText;
    private JTextField newPasswordText;
    private JTextField againPasswordText;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                RevisePassword frame = new RevisePassword();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame with optimized layout.
     */
    public RevisePassword() {
        // Set frame properties
        setTitle("Revise Password");
        setBounds(100, 100, 450, 400); // Adjusted size for better spacing
        setLocationRelativeTo(null); // Center window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout()); // Using GridBagLayout for better control

        // Create layout constraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title
        JLabel lblTitle = new JLabel("Modify Password", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(lblTitle, gbc);

        // User type label
        JLabel lblUserType = new JLabel("Current User:");
        lblUserType.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(lblUserType, gbc);

        // User information
        String userTypeStr = StudentFrame.userType.getName();
        String userNameStr = StudentFrame.student.getName();
        JLabel lblUserInfo = new JLabel("[" + userTypeStr + "] " + userNameStr);
        lblUserInfo.setFont(new Font("Arial", Font.BOLD, 14));
        lblUserInfo.setForeground(Color.RED);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(lblUserInfo, gbc);

        // Old password label and text field
        JLabel lblOldPassword = new JLabel("Old Password:");
        lblOldPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lblOldPassword, gbc);

        oldPasswordText = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(oldPasswordText, gbc);

        // New password label and text field
        JLabel lblNewPassword = new JLabel("New Password:");
        lblNewPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(lblNewPassword, gbc);

        newPasswordText = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(newPasswordText, gbc);

        // Confirm password label and text field
        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 4;
        add(lblConfirmPassword, gbc);

        againPasswordText = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 4;
        add(againPasswordText, gbc);

        // Buttons panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 0));

        // Confirm button
        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.setFont(new Font("Arial", Font.PLAIN, 14));
        btnConfirm.addActionListener(this::confirmButton);
        buttonsPanel.add(btnConfirm);

        // Reset button
        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 14));
        btnReset.addActionListener(this::resetButton);
        buttonsPanel.add(btnReset);

        // Close button
        JButton btnClose = new JButton("Close");
        btnClose.setFont(new Font("Arial", Font.PLAIN, 14));
        btnClose.addActionListener(e -> this.dispose());
        buttonsPanel.add(btnClose);

        // Add buttons panel to layout
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        add(buttonsPanel, gbc);

        setVisible(true);
    }

    /**
     * Handles confirmation of password change.
     */
    protected void confirmButton(ActionEvent e) {
        String oldPassword = oldPasswordText.getText();
        String newPassword = newPasswordText.getText();
        String confirmPassword = againPasswordText.getText();

        if (StrUtil.isEmpty(oldPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the old password.");
            return;
        }

        if (StrUtil.isEmpty(newPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the new password.");
            return;
        }

        if (StrUtil.isEmpty(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Please confirm the new password.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "New password and confirmation do not match.");
            return;
        }

        try {
            if ("System Administrator".equals(StudentFrame.userType.getName())) {
                AdminDao adminDao = new AdminDao();
                JOptionPane.showMessageDialog(this, adminDao.revisePassword(String.valueOf(IndexFrame.admin), newPassword));
            } else if ("Student".equals(StudentFrame.userType.getName())) {
                StudentDao studentDao = new StudentDao();
                JOptionPane.showMessageDialog(this, studentDao.revisePassword(String.valueOf(StudentFrame.student), newPassword));
            } else if ("Teacher".equals(StudentFrame.userType.getName())) {
                TeacherDao teacherDao = new TeacherDao();
                JOptionPane.showMessageDialog(this, teacherDao.revisePassword(String.valueOf(TeacherFrame.teacher), newPassword));
            }
            resetButton(e);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error while updating password: " + ex.getMessage());
        }
    }

    /**
     * Clears all input fields.
     */
    protected void resetButton(ActionEvent e) {
        oldPasswordText.setText("");
        newPasswordText.setText("");
        againPasswordText.setText("");
    }
}
