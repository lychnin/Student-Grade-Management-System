package view.Student;

import dao.StudentDao;
import view.StudentFrame;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class StudentInfo extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                StudentInfo frame = new StudentInfo();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public StudentInfo() throws SQLException {
        // Frame configuration
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 400);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Fetch student data
        String stuName = StudentFrame.student.getName();
        StudentDao studentDao = new StudentDao();
        String stuDept = studentDao.getDept(stuName);
        String stuId = studentDao.getId(stuName);
        String stuAge = studentDao.getAge(stuName);
        String stuSex = studentDao.getSex(stuName);

        // Title
        JLabel lblTitle = new JLabel("Student Information");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setBounds(140, 20, 220, 30);
        contentPane.add(lblTitle);

        int labelX = 80;  // X-coordinate for labels
        int valueX = 180; // X-coordinate for values
        int startY = 80;  // Y-coordinate start position
        int lineHeight = 40; // Height between lines

        // Labels and values
        JLabel lblId = new JLabel("ID:");
        lblId.setFont(new Font("Arial", Font.PLAIN, 16));
        lblId.setBounds(labelX, startY, 100, 30);
        contentPane.add(lblId);

        JLabel lblIdValue = new JLabel(stuId);
        lblIdValue.setFont(new Font("Arial", Font.PLAIN, 16));
        lblIdValue.setBounds(valueX, startY, 200, 30);
        contentPane.add(lblIdValue);

        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Arial", Font.PLAIN, 16));
        lblName.setBounds(labelX, startY + lineHeight, 100, 30);
        contentPane.add(lblName);

        JLabel lblNameValue = new JLabel(stuName);
        lblNameValue.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNameValue.setBounds(valueX, startY + lineHeight, 200, 30);
        contentPane.add(lblNameValue);

        JLabel lblSex = new JLabel("Gender:");
        lblSex.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSex.setBounds(labelX, startY + lineHeight * 2, 100, 30);
        contentPane.add(lblSex);

        JLabel lblSexValue = new JLabel(stuSex);
        lblSexValue.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSexValue.setBounds(valueX, startY + lineHeight * 2, 200, 30);
        contentPane.add(lblSexValue);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setFont(new Font("Arial", Font.PLAIN, 16));
        lblAge.setBounds(labelX, startY + lineHeight * 3, 100, 30);
        contentPane.add(lblAge);

        JLabel lblAgeValue = new JLabel(stuAge);
        lblAgeValue.setFont(new Font("Arial", Font.PLAIN, 16));
        lblAgeValue.setBounds(valueX, startY + lineHeight * 3, 200, 30);
        contentPane.add(lblAgeValue);

        JLabel lblDept = new JLabel("Major:");
        lblDept.setFont(new Font("Arial", Font.PLAIN, 16));
        lblDept.setBounds(labelX, startY + lineHeight * 4, 100, 30);
        contentPane.add(lblDept);

        JLabel lblDeptValue = new JLabel(stuDept);
        lblDeptValue.setFont(new Font("Arial", Font.PLAIN, 16));
        lblDeptValue.setBounds(valueX, startY + lineHeight * 4, 200, 30);
        contentPane.add(lblDeptValue);

        // Close button
        JButton btnClose = new JButton("Close");
        btnClose.setFont(new Font("Arial", Font.PLAIN, 14));
        btnClose.setBounds(350, 320, 100, 30);
        btnClose.addActionListener(this::closeButton);
        contentPane.add(btnClose);

        // Notify user that data has been loaded
        JOptionPane.showMessageDialog(this, "Student information loaded successfully.");
    }

    protected void closeButton(ActionEvent e) {
        this.dispose();
    }
}
