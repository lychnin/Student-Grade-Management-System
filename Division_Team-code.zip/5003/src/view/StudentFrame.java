package view;

import model.Student;
import model.UserType;
import view.Student.ChooseCourseFrame;
import view.Student.FindGradeFrame;
import view.Student.RevisePassword;
import view.Student.StudentInfo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

/**
 * Student dashboard interface after login.
 */
public class StudentFrame extends JFrame {

    private JPanel contentPane;
    public static UserType userType;
    public static Student student;

    /**
     * Constructor to create the StudentFrame.
     */
    public StudentFrame(UserType u, Student s) {
        // Assign user type and student details
        userType = u;
        student = s;

        // Frame properties
        setTitle("Student Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Adjusted frame size
        setLocationRelativeTo(null);

        // Content pane setup
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(240, 248, 255)); // Light blue background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Header label
        JLabel lblNewLabel = new JLabel("Current User:");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel.setBounds(50, 30, 120, 25);
        contentPane.add(lblNewLabel);

        // User details label
        JLabel lblxxx = new JLabel("【" + u.getName() + "】" + s.getName());
        lblxxx.setForeground(new Color(255, 69, 0)); // Red
        lblxxx.setFont(new Font("Arial", Font.BOLD, 16));
        lblxxx.setBounds(180, 30, 250, 25);
        contentPane.add(lblxxx);

        // "User Info" button
        JButton btnUserInfo = new JButton("User Info");
        btnUserInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        btnUserInfo.setBounds(50, 100, 150, 35);
        btnUserInfo.setBackground(new Color(173, 216, 230)); // Light blue
        btnUserInfo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    studentInfo(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnUserInfo);

        // "Course Registration" button
        JButton btnCourseRegister = new JButton("Course Registration");
        btnCourseRegister.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCourseRegister.setBounds(280, 100, 150, 35);
        btnCourseRegister.setBackground(new Color(173, 216, 230));
        btnCourseRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                chooseCourse(ae);
            }
        });
        contentPane.add(btnCourseRegister);

        // "Grade Inquiry" button
        JButton btnGradeInquiry = new JButton("Grade Inquiry");
        btnGradeInquiry.setFont(new Font("Arial", Font.PLAIN, 14));
        btnGradeInquiry.setBounds(50, 160, 150, 35);
        btnGradeInquiry.setBackground(new Color(144, 238, 144)); // Light green
        btnGradeInquiry.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findGrade(e);
            }
        });
        contentPane.add(btnGradeInquiry);

        // "Change Password" button
        JButton btnChangePassword = new JButton("Change Password");
        btnChangePassword.setFont(new Font("Arial", Font.PLAIN, 14));
        btnChangePassword.setBounds(280, 160, 150, 35);
        btnChangePassword.setBackground(new Color(255, 182, 193)); // Light pink
        btnChangePassword.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                revisePassword(e);
            }
        });
        contentPane.add(btnChangePassword);

        // "Exit System" button
        JButton btnExitSystem = new JButton("Exit System");
        btnExitSystem.setFont(new Font("Arial", Font.PLAIN, 14));
        btnExitSystem.setBounds(170, 230, 150, 35);
        btnExitSystem.setBackground(new Color(240, 128, 128)); // Light coral
        btnExitSystem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExitSystem);
    }

    /**
     * Handles the "Exit System" button click.
     */
    private void exitButton(ActionEvent e) {
        this.dispose();
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }

    /**
     * Opens the "Course Registration" frame.
     */
    private void chooseCourse(ActionEvent ae) {
        ChooseCourseFrame chooseCourseFrame = new ChooseCourseFrame();
        chooseCourseFrame.setVisible(true);
    }

    /**
     * Opens the "Grade Inquiry" frame.
     */
    protected void findGrade(ActionEvent e) {
        FindGradeFrame findGradeFrame = new FindGradeFrame();
        findGradeFrame.setVisible(true);
    }

    /**
     * Opens the "Change Password" frame.
     */
    private void revisePassword(ActionEvent e) {
        RevisePassword revisePassword = new RevisePassword();
        revisePassword.setVisible(true);
    }

    /**
     * Opens the "User Info" frame.
     */
    protected void studentInfo(ActionEvent e) throws SQLException {
        StudentInfo studentInfo = new StudentInfo();
        studentInfo.setVisible(true);
    }
}
