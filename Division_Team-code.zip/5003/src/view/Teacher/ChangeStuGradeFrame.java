package view.Teacher;

import dao.TeacherDao;
import view.TeacherFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class ChangeStuGradeFrame extends JFrame {

    private JPanel contentPane;
    private JTextField StuName;
    private JTextField ChangeGrade;
    private JLabel PreStuGrade;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ChangeStuGradeFrame frame = new ChangeStuGradeFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public ChangeStuGradeFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400); // Adjust window size
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Adjust margins
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Edit Student Grade");
        lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 24)); // Increase font size
        lblNewLabel.setBounds(200, 20, 250, 40); // Adjust title display width
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Student Name:");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 18)); // Increase font size
        lblNewLabel_1.setBounds(50, 80, 140, 25);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("Original Grade:");
        lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 18));
        lblNewLabel_1_1.setBounds(50, 130, 140, 25);
        contentPane.add(lblNewLabel_1_1);

        JLabel lblNewLabel_1_1_1 = new JLabel("Change to:");
        lblNewLabel_1_1_1.setFont(new Font("Arial", Font.PLAIN, 18));
        lblNewLabel_1_1_1.setBounds(50, 180, 140, 25);
        contentPane.add(lblNewLabel_1_1_1);

        StuName = new JTextField();
        StuName.setBounds(200, 80, 300, 30); // Adjust text box width
        contentPane.add(StuName);
        StuName.setColumns(10);

        PreStuGrade = new JLabel();
        PreStuGrade.setFont(new Font("Arial", Font.PLAIN, 18));
        PreStuGrade.setBounds(200, 130, 300, 25); // Adjust width
        contentPane.add(PreStuGrade);

        ChangeGrade = new JTextField();
        ChangeGrade.setColumns(10);
        ChangeGrade.setBounds(200, 180, 300, 30); // Adjust text box width
        contentPane.add(ChangeGrade);

        JButton btnNewButton = new JButton("Search");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    findStuGrade(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton.setBounds(100, 240, 120, 35); // Adjust button size
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Edit");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    changeStuGrade(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton_1.setBounds(250, 240, 120, 35);
        contentPane.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("Reset");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton_2.setBounds(400, 240, 120, 35);
        contentPane.add(btnNewButton_2);

        JButton btnNewButton_2_1 = new JButton("Exit");
        btnNewButton_2_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        btnNewButton_2_1.setFont(new Font("Arial", Font.PLAIN, 18));
        btnNewButton_2_1.setBounds(250, 300, 120, 35);
        contentPane.add(btnNewButton_2_1);
    }

    protected void findStuGrade(ActionEvent e) throws SQLException {
        TeacherDao teacherDao = new TeacherDao();
        String stuName = this.StuName.getText();
        String teacherName = TeacherFrame.teacher.getName();
        String courseName = teacherDao.getTeachCourse(teacherName);
        String preStuGrade = teacherDao.FindStuGrade(stuName, courseName);
        PreStuGrade.setText(preStuGrade);
    }

    protected void changeStuGrade(ActionEvent e) throws SQLException {
        TeacherDao teacherDao = new TeacherDao();
        String stuName = this.StuName.getText();
        String teacherName = TeacherFrame.teacher.getName();
        String courseName = teacherDao.getTeachCourse(teacherName);
        int changeGrade = Integer.parseInt(this.ChangeGrade.getText());
        String result = teacherDao.ChangeStuGrade(stuName, courseName, changeGrade);
        JOptionPane.showMessageDialog(this, result);
        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        this.PreStuGrade.setText("");
        this.StuName.setText("");
        this.ChangeGrade.setText("");
    }

    protected void exitButton(ActionEvent e) {
        this.setVisible(false);
    }
}
