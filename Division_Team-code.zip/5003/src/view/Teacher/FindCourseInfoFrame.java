package view.Teacher;

import dao.TeacherDao;
import view.TeacherFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class FindCourseInfoFrame extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FindCourseInfoFrame frame = new FindCourseInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public FindCourseInfoFrame() throws SQLException {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400); // Adjust window size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        TeacherDao teacherDao = new TeacherDao();
        String teacherName = TeacherFrame.teacher.getName();
        String TeachCourseName = teacherDao.getTeachCourse(teacherName);
        String TeachCourseID = teacherDao.getTeachCourseID(teacherName);

        JLabel lblNewLabel = new JLabel("Course Information");
        lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 24)); // Increase font size
        lblNewLabel.setBounds(200, 20, 300, 40); // Adjust title width
        contentPane.add(lblNewLabel);

        JLabel lblTeacherName = new JLabel("Teacher Name:");
        lblTeacherName.setFont(new Font("Arial", Font.PLAIN, 18)); // Increase font size
        lblTeacherName.setBounds(50, 80, 150, 30);
        contentPane.add(lblTeacherName);

        JLabel lblCourseName = new JLabel("Course Name:");
        lblCourseName.setFont(new Font("Arial", Font.PLAIN, 18));
        lblCourseName.setBounds(50, 130, 150, 30);
        contentPane.add(lblCourseName);

        JLabel lblCourseID = new JLabel("Course ID:");
        lblCourseID.setFont(new Font("Arial", Font.PLAIN, 18));
        lblCourseID.setBounds(50, 180, 150, 30);
        contentPane.add(lblCourseID);

        JLabel lblTeacherNameValue = new JLabel(teacherName);
        lblTeacherNameValue.setFont(new Font("Arial", Font.PLAIN, 18));
        lblTeacherNameValue.setBounds(210, 80, 350, 30); // Adjust width to display full content
        contentPane.add(lblTeacherNameValue);

        JLabel lblCourseNameValue = new JLabel(TeachCourseName);
        lblCourseNameValue.setFont(new Font("Arial", Font.PLAIN, 18));
        lblCourseNameValue.setBounds(210, 130, 350, 30);
        contentPane.add(lblCourseNameValue);

        JLabel lblCourseIDValue = new JLabel(TeachCourseID);
        lblCourseIDValue.setFont(new Font("Arial", Font.PLAIN, 18));
        lblCourseIDValue.setBounds(210, 180, 350, 30);
        contentPane.add(lblCourseIDValue);

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                closeButton(e);
            }
        });
        btnClose.setFont(new Font("Arial", Font.PLAIN, 18));
        btnClose.setBounds(250, 250, 100, 40); // Adjust button size
        contentPane.add(btnClose);
    }

    protected void closeButton(ActionEvent e) {
        this.setVisible(false);
    }
}
