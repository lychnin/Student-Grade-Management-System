package view.Teacher;

import dao.TeacherDao;
import view.TeacherFrame;

import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class FindStuGradeFrame extends JFrame {

    private JPanel contentPane;
    private JTextField StuName;
    private JLabel StuGrade;
    private String grade = null;

    /**
     * Entry point to launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FindStuGradeFrame frame = new FindStuGradeFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Constructor to create the frame.
     */
    public FindStuGradeFrame() {
        // Set the frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400); // Adjusted the frame size for better layout
        setLocationRelativeTo(null); // Center the frame on the screen
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Create and add the title label
        JLabel lblNewLabel = new JLabel("Query Student Grade");
        lblNewLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 24));
        lblNewLabel.setBounds(180, 30, 300, 40);
        contentPane.add(lblNewLabel);

        // Label for student name input
        JLabel lblNewLabel_1 = new JLabel("Student Name:");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 18));
        lblNewLabel_1.setBounds(100, 100, 150, 30);
        contentPane.add(lblNewLabel_1);

        // Label for student grade output
        JLabel lblNewLabel_1_1 = new JLabel("Student Grade:");
        lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 18));
        lblNewLabel_1_1.setBounds(100, 160, 150, 30);
        contentPane.add(lblNewLabel_1_1);

        // Text field for entering the student name
        StuName = new JTextField();
        StuName.setBounds(260, 100, 200, 30);
        contentPane.add(StuName);
        StuName.setColumns(10);

        // Label for displaying the student grade
        StuGrade = new JLabel();
        StuGrade.setFont(new Font("Arial", Font.PLAIN, 18));
        StuGrade.setBounds(260, 160, 200, 30);
        contentPane.add(StuGrade);

        // Button to query the student grade
        JButton btnNewButton = new JButton("Query");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    findStuGrade(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Microsoft YaHei", Font.PLAIN, 18));
        btnNewButton.setBounds(80, 250, 120, 40);
        contentPane.add(btnNewButton);

        // Button to reset the input and output fields
        JButton btnNewButton_1 = new JButton("Reset");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        btnNewButton_1.setFont(new Font("Microsoft YaHei", Font.PLAIN, 18));
        btnNewButton_1.setBounds(240, 250, 120, 40);
        contentPane.add(btnNewButton_1);

        // Button to exit the frame
        JButton btnNewButton_1_1 = new JButton("Exit");
        btnNewButton_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        btnNewButton_1_1.setFont(new Font("Microsoft YaHei", Font.PLAIN, 18));
        btnNewButton_1_1.setBounds(400, 250, 120, 40);
        contentPane.add(btnNewButton_1_1);
    }

    /**
     * Method to find the grade of a student based on their name.
     */
    protected void findStuGrade(ActionEvent e) throws SQLException {
        TeacherDao teacherDao = new TeacherDao();
        String stuName = this.StuName.getText();
        String teacherName = TeacherFrame.teacher.getName();
        String courseName = teacherDao.getTeachCourse(teacherName);
        grade = teacherDao.FindStuGrade(stuName, courseName);
        this.StuGrade.setText(grade);

        if (grade == null) {
            JOptionPane.showMessageDialog(this, "The student has not selected this course or the grade is not yet available!");
        }
    }

    /**
     * Method to reset the input and output fields.
     */
    protected void resetButton(ActionEvent e) {
        this.StuName.setText("");
        this.StuGrade.setText("");
    }

    /**
     * Method to exit and close the frame.
     */
    protected void exitButton(ActionEvent e) {
        this.setVisible(false);
    }
}
