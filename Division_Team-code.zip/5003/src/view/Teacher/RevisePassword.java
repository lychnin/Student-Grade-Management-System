package view.Teacher;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Font;
import java.awt.Color;

import dao.AdminDao;
import dao.StudentDao;
import dao.TeacherDao;
import util.StrUtil;
import view.IndexFrame;
import view.StudentFrame;
import view.TeacherFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RevisePassword extends JFrame {

    private JTextField oldPasswordText;
    private JTextField newPasswordText;
    private JTextField againPasswordText;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                RevisePassword frame = new RevisePassword();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Constructor to create the password revision frame.
     */
    public RevisePassword() {
        // Set frame properties
        setTitle("Revise Password");
        setBounds(100, 100, 500, 350); // Adjusted frame size for better layout
        setLocationRelativeTo(null); // Center the frame on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this frame
        getContentPane().setLayout(null);

        // Label for the current user
        JLabel lblNewLabel = new JLabel("Current User:");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
        lblNewLabel.setBounds(70, 29, 100, 25);
        getContentPane().add(lblNewLabel);

        // Display the user type and name
        String userTypeStr = TeacherFrame.userType.getName();
        String teacherNameStr = TeacherFrame.teacher.getName();
        JLabel lblAdmin = new JLabel("【" + userTypeStr + "】" + teacherNameStr);
        lblAdmin.setForeground(new Color(255, 0, 0));
        lblAdmin.setFont(new Font("Arial", Font.BOLD, 14));
        lblAdmin.setBounds(170, 29, 250, 25);
        getContentPane().add(lblAdmin);

        // Label for old password
        JLabel lblOldPassword = new JLabel("Old Password:");
        lblOldPassword.setFont(new Font("Arial", Font.BOLD, 14));
        lblOldPassword.setBounds(70, 80, 120, 25);
        getContentPane().add(lblOldPassword);

        // Label for new password
        JLabel lblNewPassword = new JLabel("New Password:");
        lblNewPassword.setFont(new Font("Arial", Font.BOLD, 14));
        lblNewPassword.setBounds(70, 130, 120, 25);
        getContentPane().add(lblNewPassword);

        // Label for re-enter password
        JLabel lblAgainPassword = new JLabel("Re-enter:");
        lblAgainPassword.setFont(new Font("Arial", Font.BOLD, 14));
        lblAgainPassword.setBounds(70, 180, 120, 25);
        getContentPane().add(lblAgainPassword);

        // Text field for old password input
        oldPasswordText = new JPasswordField();
        oldPasswordText.setBounds(200, 80, 200, 25);
        getContentPane().add(oldPasswordText);

        // Text field for new password input
        newPasswordText = new JPasswordField();
        newPasswordText.setBounds(200, 130, 200, 25);
        getContentPane().add(newPasswordText);

        // Text field for re-entering new password
        againPasswordText = new JPasswordField();
        againPasswordText.setBounds(200, 180, 200, 25);
        getContentPane().add(againPasswordText);

        // Button to confirm password change
        JButton btnConfirm = new JButton("Confirm Change");
        btnConfirm.addActionListener(e -> confirmButton(e));
        btnConfirm.setFont(new Font("Arial", Font.BOLD, 14));
        btnConfirm.setBounds(80, 250, 150, 30);
        getContentPane().add(btnConfirm);

        // Button to reset input fields
        JButton btnReset = new JButton("Reset");
        btnReset.addActionListener(e -> resetButton(e));
        btnReset.setFont(new Font("Arial", Font.BOLD, 14));
        btnReset.setBounds(270, 250, 100, 30);
        getContentPane().add(btnReset);

        setVisible(true);
    }

    /**
     * Handles the confirm button click event.
     * Validates input and changes the password based on the user type.
     */
    protected void confirmButton(ActionEvent e) {
        String oldPassword = this.oldPasswordText.getText();
        String newPassword = this.newPasswordText.getText();
        String againPassword = this.againPasswordText.getText();

        if (StrUtil.isEmpty(oldPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the old password.");
            return;
        }
        if (StrUtil.isEmpty(newPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the new password.");
            return;
        }
        if (StrUtil.isEmpty(againPassword)) {
            JOptionPane.showMessageDialog(this, "Please re-enter the new password.");
            return;
        }
        if (!newPassword.equals(againPassword)) {
            JOptionPane.showMessageDialog(this, "The new passwords do not match!");
            return;
        }

        // Handle password change based on user type
        try {
            if ("System Administrator".equals(TeacherFrame.userType.getName())) {
                AdminDao adminDao = new AdminDao();
                JOptionPane.showMessageDialog(this, adminDao.revisePassword(String.valueOf(IndexFrame.admin), newPassword));
            } else if ("Student".equals(TeacherFrame.userType.getName())) {
                StudentDao studentDao = new StudentDao();
                JOptionPane.showMessageDialog(this, studentDao.revisePassword(String.valueOf(StudentFrame.student), newPassword));
            } else if ("Teacher".equals(TeacherFrame.userType.getName())) {
                TeacherDao teacherDao = new TeacherDao();
                JOptionPane.showMessageDialog(this, teacherDao.revisePassword(String.valueOf(TeacherFrame.teacher), newPassword));
                resetButton(e); // Reset fields after successful password change
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error changing password: " + ex.getMessage());
        }
    }

    /**
     * Resets all input fields.
     */
    protected void resetButton(ActionEvent e) {
        this.oldPasswordText.setText("");
        this.newPasswordText.setText("");
        this.againPasswordText.setText("");
    }
}
