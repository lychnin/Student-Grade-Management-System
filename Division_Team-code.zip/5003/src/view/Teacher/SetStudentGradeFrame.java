package view.Teacher;

import dao.TeacherDao;
import view.TeacherFrame;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class SetStudentGradeFrame extends JFrame {

    private JPanel contentPane;
    private JTextField StuName;
    private JTextField StuGrade;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SetStudentGradeFrame frame = new SetStudentGradeFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public SetStudentGradeFrame() {
        // Frame properties
        setTitle("Set Student Grade");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Adjusted frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title label
        JLabel lblNewLabel = new JLabel("Enter Student Grade");
        lblNewLabel.setFont(new Font("Microsoft YaHei", Font.PLAIN, 20));
        lblNewLabel.setBounds(150, 30, 200, 30);
        contentPane.add(lblNewLabel);

        // Label for student name
        JLabel lblNewLabel_1 = new JLabel("Student Name:");
        lblNewLabel_1.setFont(new Font("Microsoft YaHei", Font.PLAIN, 15));
        lblNewLabel_1.setBounds(100, 90, 120, 30);
        contentPane.add(lblNewLabel_1);

        // Label for grade
        JLabel lblNewLabel_1_1 = new JLabel("Grade:");
        lblNewLabel_1_1.setFont(new Font("Microsoft YaHei", Font.PLAIN, 15));
        lblNewLabel_1_1.setBounds(100, 140, 120, 30);
        contentPane.add(lblNewLabel_1_1);

        // Input for student name
        StuName = new JTextField();
        StuName.setBounds(220, 90, 150, 30);
        contentPane.add(StuName);
        StuName.setColumns(10);

        // Input for grade
        StuGrade = new JTextField();
        StuGrade.setColumns(10);
        StuGrade.setBounds(220, 140, 150, 30);
        contentPane.add(StuGrade);

        // Button to submit the grade
        JButton btnNewButton = new JButton("Enter");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    setStudentGrade(e);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SetStudentGradeFrame.this, "Error: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        btnNewButton.setBounds(70, 220, 100, 30);
        contentPane.add(btnNewButton);

        // Button to reset the fields
        JButton btnReset = new JButton("Reset");
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        btnReset.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        btnReset.setBounds(200, 220, 100, 30);
        contentPane.add(btnReset);

        // Button to exit the frame
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        btnExit.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));
        btnExit.setBounds(330, 220, 100, 30);
        contentPane.add(btnExit);
    }

    /**
     * Handles the action of setting the student's grade.
     */
    protected void setStudentGrade(ActionEvent e) throws SQLException {
        TeacherDao teacherDao = new TeacherDao();
        String stuName = this.StuName.getText().trim();
        String gradeText = this.StuGrade.getText().trim();

        // Input validation
        if (stuName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the student's name.");
            return;
        }
        if (gradeText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the grade.");
            return;
        }

        try {
            int grade = Integer.parseInt(gradeText);
            String teacherName = TeacherFrame.teacher.getName();
            String courseName = teacherDao.getTeachCourse(teacherName);

            // Set the grade and provide feedback
            String result = teacherDao.SetStudentGrade(stuName, courseName, grade);
            JOptionPane.showMessageDialog(this, result);
            this.resetButton(e);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Grade must be a valid number.");
        }
    }

    /**
     * Resets the input fields.
     */
    protected void resetButton(ActionEvent e) {
        this.StuName.setText("");
        this.StuGrade.setText("");
    }

    /**
     * Exits the frame.
     */
    protected void exitButton(ActionEvent e) {
        this.setVisible(false);
    }
}
