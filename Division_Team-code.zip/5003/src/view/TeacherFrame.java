package view;

import model.Teacher;
import model.UserType;
import view.Teacher.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class TeacherFrame extends JFrame {

    private JPanel contentPane;
    public static UserType userType;
    public static Teacher teacher;

    /**
     * Constructor to create the teacher dashboard frame.
     */
    public TeacherFrame(UserType u, Teacher t) {
        // Assign user type and teacher details
        userType = u;
        teacher = t;

        // Frame properties
        setTitle("Teacher Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 500); // Adjusted frame size
        setLocationRelativeTo(null);

        // Content pane setup
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(240, 248, 255)); // Light blue background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Header label for user details
        JLabel lblNewLabel = new JLabel("Current User:");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel.setBounds(50, 30, 120, 30);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("【" + u.getName() + "】" + t.getName());
        lblNewLabel_1.setForeground(Color.RED);
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel_1.setBounds(180, 30, 300, 30);
        contentPane.add(lblNewLabel_1);

        // "Enter Grades" button
        JButton btnEnterGrades = new JButton("Enter Grades");
        btnEnterGrades.setFont(new Font("Arial", Font.PLAIN, 14));
        btnEnterGrades.setBounds(50, 100, 160, 40);
        btnEnterGrades.setBackground(new Color(173, 216, 230)); // Light blue
        btnEnterGrades.addActionListener(this::setStuGrade);
        contentPane.add(btnEnterGrades);

        // "View Grades" button
        JButton btnViewGrades = new JButton("View Grades");
        btnViewGrades.setFont(new Font("Arial", Font.PLAIN, 14));
        btnViewGrades.setBounds(50, 170, 160, 40);
        btnViewGrades.setBackground(new Color(173, 216, 230));
        btnViewGrades.addActionListener(this::findStuGrade);
        contentPane.add(btnViewGrades);

        // "Modify Grades" button
        JButton btnModifyGrades = new JButton("Modify Grades");
        btnModifyGrades.setFont(new Font("Arial", Font.PLAIN, 14));
        btnModifyGrades.setBounds(250, 100, 160, 40);
        btnModifyGrades.setBackground(new Color(144, 238, 144)); // Light green
        btnModifyGrades.addActionListener(this::changeStuGrade);
        contentPane.add(btnModifyGrades);

        // "View Teaching Info" button
        JButton btnViewTeachInfo = new JButton("View Teaching Info");
        btnViewTeachInfo.setFont(new Font("Arial", Font.PLAIN, 14));
        btnViewTeachInfo.setBounds(250, 170, 160, 40);
        btnViewTeachInfo.setBackground(new Color(144, 238, 144));
        btnViewTeachInfo.addActionListener(e -> {
            try {
                findTeachInfo(e);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
        contentPane.add(btnViewTeachInfo);

        // "Change Password" button
        JButton btnChangePassword = new JButton("Change Password");
        btnChangePassword.setFont(new Font("Arial", Font.PLAIN, 14));
        btnChangePassword.setBounds(450, 100, 160, 40);
        btnChangePassword.setBackground(new Color(255, 182, 193)); // Light pink
        btnChangePassword.addActionListener(this::revisePassword);
        contentPane.add(btnChangePassword);

        // "Log Out" button
        JButton btnLogOut = new JButton("Log Out");
        btnLogOut.setFont(new Font("Arial", Font.PLAIN, 14));
        btnLogOut.setBounds(450, 170, 160, 40);
        btnLogOut.setBackground(new Color(240, 128, 128)); // Light coral
        btnLogOut.addActionListener(this::exitButton);
        contentPane.add(btnLogOut);
    }

    /**
     * Handles the "Log Out" button click.
     */
    private void exitButton(ActionEvent e) {
        this.dispose();
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }

    /**
     * Opens the "View Teaching Info" frame.
     */
    protected void findTeachInfo(ActionEvent e) throws SQLException {
        FindCourseInfoFrame findCourseInfoFrame = new FindCourseInfoFrame();
        findCourseInfoFrame.setVisible(true);
    }

    /**
     * Opens the "Change Password" frame.
     */
    private void revisePassword(ActionEvent e) {
        RevisePassword revisePassword = new RevisePassword();
        revisePassword.setVisible(true);
    }

    /**
     * Opens the "Enter Grades" frame.
     */
    protected void setStuGrade(ActionEvent e) {
        SetStudentGradeFrame setStudentGradeFrame = new SetStudentGradeFrame();
        setStudentGradeFrame.setVisible(true);
    }

    /**
     * Opens the "View Grades" frame.
     */
    protected void findStuGrade(ActionEvent e) {
        FindStuGradeFrame findStuGradeFrame = new FindStuGradeFrame();
        findStuGradeFrame.setVisible(true);
    }

    /**
     * Opens the "Modify Grades" frame.
     */
    protected void changeStuGrade(ActionEvent e) {
        ChangeStuGradeFrame changeStuGradeFrame = new ChangeStuGradeFrame();
        changeStuGradeFrame.setVisible(true);
    }
}
