package view.systemManager;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import dao.StudentDao;
import util.StrUtil;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddStudentFrame extends JFrame {

    private JPanel contentPane;
    private JTextField NewAddStuName;
    private JTextField NewAddStuPassword;
    private JTextField NewAddStuID;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddStudentFrame frame = new AddStudentFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    // Administrator interface for adding a student
    public AddStudentFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Adjusted padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Name:");
        lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel.setBounds(100, 150, 80, 20);
        contentPane.add(lblNewLabel);

        NewAddStuName = new JTextField();
        NewAddStuName.setFont(new Font("Arial", Font.PLAIN, 16));
        NewAddStuName.setBounds(190, 150, 200, 30); // Increased width and height
        contentPane.add(NewAddStuName);
        NewAddStuName.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Password:");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(100, 190, 80, 20);
        contentPane.add(lblNewLabel_1);

        NewAddStuPassword = new JTextField();
        NewAddStuPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        NewAddStuPassword.setBounds(190, 190, 200, 30);
        contentPane.add(NewAddStuPassword);
        NewAddStuPassword.setColumns(10);

        JButton btnNewButton = new JButton("Confirm Add");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddStuLogin(e);
            }
        });
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton.setBounds(70, 250, 130, 30);
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Reset");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_1.setBounds(210, 250, 130, 30);
        contentPane.add(btnNewButton_1);

        JLabel lblNewLabel_2 = new JLabel("Add Student");
        lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 28)); // Increased font size
        lblNewLabel_2.setBounds(150, 50, 200, 50); // Adjusted position
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("ID:");
        lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_3.setBounds(100, 110, 80, 20);
        contentPane.add(lblNewLabel_3);

        NewAddStuID = new JTextField();
        NewAddStuID.setFont(new Font("Arial", Font.PLAIN, 16));
        NewAddStuID.setBounds(190, 110, 200, 30);
        contentPane.add(NewAddStuID);
        NewAddStuID.setColumns(10);

        JButton btnNewButton_1_1 = new JButton("Exit");
        btnNewButton_1_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        btnNewButton_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_1_1.setBounds(350, 250, 100, 30);
        contentPane.add(btnNewButton_1_1);
    }

    protected void exitButton(ActionEvent e) {
        // Exit the current window
        this.setVisible(false);
    }

    // Add student information
    protected void AddStuLogin(ActionEvent e) {
        String id = this.NewAddStuID.getText();
        String name = this.NewAddStuName.getText();
        String password = this.NewAddStuPassword.getText();
        if (StrUtil.isEmpty(id)) {
            JOptionPane.showMessageDialog(this, "Student ID cannot be empty!");
            return;
        }
        if (StrUtil.isEmpty(name)) {
            JOptionPane.showMessageDialog(this, "Student name cannot be empty!");
            return;
        }
        if (StrUtil.isEmpty(password)) {
            JOptionPane.showMessageDialog(this, "Student password cannot be empty!");
            return;
        }
        StudentDao studentDao = new StudentDao();
        JOptionPane.showMessageDialog(this, studentDao.addStuLogin(id, name, password));
        this.resetButton(e);
    }

    // Reset button functionality
    protected void resetButton(ActionEvent e) {
        this.NewAddStuID.setText("");
        this.NewAddStuName.setText("");
        this.NewAddStuPassword.setText("");
    }
}
