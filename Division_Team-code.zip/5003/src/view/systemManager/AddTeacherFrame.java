package view.systemManager;

import dao.TeacherDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class AddTeacherFrame extends JFrame {

    private JPanel contentPane;
    private JTextField NewTeacherName;
    private JTextField NewTeacherPassword;
    private JTextField NewTeacherCourseName;
    private JTextField NewTeacherID;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddTeacherFrame frame = new AddTeacherFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AddTeacherFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 550, 400); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Add Teacher Interface");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 22)); // Increased font size for better readability
        lblNewLabel.setBounds(160, 20, 300, 40); // Adjusted position and size
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Name:");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(100, 120, 100, 25);
        contentPane.add(lblNewLabel_1);

        NewTeacherName = new JTextField();
        NewTeacherName.setFont(new Font("Arial", Font.PLAIN, 16));
        NewTeacherName.setBounds(210, 120, 200, 30); // Increased width and height
        contentPane.add(NewTeacherName);
        NewTeacherName.setColumns(10);

        JLabel lblNewLabel_1_1 = new JLabel("Password:");
        lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1.setBounds(100, 160, 100, 25);
        contentPane.add(lblNewLabel_1_1);

        NewTeacherPassword = new JTextField();
        NewTeacherPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        NewTeacherPassword.setBounds(210, 160, 200, 30);
        contentPane.add(NewTeacherPassword);
        NewTeacherPassword.setColumns(10);

        JLabel lblNewLabel_1_1_1 = new JLabel("Course Name:");
        lblNewLabel_1_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1_1.setBounds(100, 200, 120, 25);
        contentPane.add(lblNewLabel_1_1_1);

        NewTeacherCourseName = new JTextField();
        NewTeacherCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        NewTeacherCourseName.setBounds(210, 200, 200, 30);
        contentPane.add(NewTeacherCourseName);
        NewTeacherCourseName.setColumns(10);

        JLabel lblNewLabel_1_2 = new JLabel("Teacher ID:");
        lblNewLabel_1_2.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_2.setBounds(100, 80, 100, 25);
        contentPane.add(lblNewLabel_1_2);

        NewTeacherID = new JTextField();
        NewTeacherID.setFont(new Font("Arial", Font.PLAIN, 16));
        NewTeacherID.setBounds(210, 80, 200, 30);
        contentPane.add(NewTeacherID);
        NewTeacherID.setColumns(10);

        JButton btnNewButton = new JButton("Add");
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton.setBounds(100, 280, 100, 40);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    addTeacher(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Reset");
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_1.setBounds(220, 280, 100, 40);
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("Exit");
        btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_2.setBounds(340, 280, 100, 40);
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnNewButton_2);
    }

    protected void addTeacher(ActionEvent e) throws SQLException {
        // Add teacher information
        TeacherDao teacherDao = new TeacherDao();
        int TeacherID = Integer.parseInt(this.NewTeacherID.getText());
        String TeacherName = this.NewTeacherName.getText();
        String TeacherPassword = this.NewTeacherPassword.getText();
        String TeachCourseName = this.NewTeacherCourseName.getText();
        String result = teacherDao.AddTeacher(TeacherID, TeacherName, TeacherPassword, TeachCourseName);
        JOptionPane.showMessageDialog(this, result);
        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        // Reset input fields
        this.NewTeacherCourseName.setText("");
        this.NewTeacherName.setText("");
        this.NewTeacherPassword.setText("");
        this.NewTeacherID.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Close the window
        this.dispose();
    }
}
