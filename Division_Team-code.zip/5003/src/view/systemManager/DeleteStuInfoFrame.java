package view.systemManager;

import dao.StudentDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class DeleteStuInfoFrame extends JFrame {

    private JPanel contentPane;
    private JTextField DeleteStuName;
    private JTextField DeleteStuID;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DeleteStuInfoFrame frame = new DeleteStuInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public DeleteStuInfoFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 350); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Delete Student");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 26)); // Increased font size
        lblNewLabel.setBounds(150, 20, 200, 40);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Student Name to Delete:");
        lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1.setBounds(50, 100, 200, 30);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("Student ID to Delete:");
        lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1.setBounds(50, 150, 200, 30);
        contentPane.add(lblNewLabel_1_1);

        DeleteStuName = new JTextField();
        DeleteStuName.setFont(new Font("Arial", Font.PLAIN, 16));
        DeleteStuName.setBounds(250, 100, 180, 30); // Increased size for better visibility
        contentPane.add(DeleteStuName);
        DeleteStuName.setColumns(10);

        DeleteStuID = new JTextField();
        DeleteStuID.setFont(new Font("Arial", Font.PLAIN, 16));
        DeleteStuID.setColumns(10);
        DeleteStuID.setBounds(250, 150, 180, 30); // Increased size
        contentPane.add(DeleteStuID);

        JButton btnNewButton = new JButton("Confirm Delete");
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton.setBounds(50, 220, 150, 40); // Increased size for better appearance
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    deleteStu(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Reset");
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_1.setBounds(210, 220, 100, 40);
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("Exit");
        btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 16));
        btnNewButton_2.setBounds(330, 220, 100, 40);
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnNewButton_2);
    }

    protected void deleteStu(ActionEvent e) throws SQLException {
        // Delete student information
        StudentDao studentDao = new StudentDao();
        String StuName = this.DeleteStuName.getText();
        int StuID = Integer.parseInt(this.DeleteStuID.getText());
        String result = studentDao.deleteStuInfo(StuName, StuID);
        JOptionPane.showMessageDialog(this, result);
        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        // Reset input fields
        this.DeleteStuID.setText("");
        this.DeleteStuName.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Exit the window
        this.setVisible(false);
    }
}
