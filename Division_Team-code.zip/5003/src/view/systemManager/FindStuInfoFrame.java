package view.systemManager;

import dao.StudentDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class FindStuInfoFrame extends JFrame {

    private JPanel contentPane;
    private JTextField FindStuName;
    private JLabel lblStuID;
    private JLabel lblStuSex;
    private JLabel lblStuAge;
    private JLabel lblStuDept;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FindStuInfoFrame frame = new FindStuInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public FindStuInfoFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 550, 400); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Find Student Information");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22)); // Increased font size
        lblTitle.setBounds(150, 20, 300, 40); // Adjusted position
        contentPane.add(lblTitle);

        JLabel lblPrompt = new JLabel("Enter Student Name to Search:");
        lblPrompt.setFont(new Font("Arial", Font.PLAIN, 16));
        lblPrompt.setBounds(50, 80, 250, 30); // Adjusted position
        contentPane.add(lblPrompt);

        FindStuName = new JTextField();
        FindStuName.setFont(new Font("Arial", Font.PLAIN, 16));
        FindStuName.setBounds(310, 80, 180, 30); // Increased size
        contentPane.add(FindStuName);
        FindStuName.setColumns(10);

        JLabel lblID = new JLabel("ID:");
        lblID.setFont(new Font("Arial", Font.PLAIN, 16));
        lblID.setBounds(50, 130, 100, 30);
        contentPane.add(lblID);

        lblStuID = new JLabel();
        lblStuID.setFont(new Font("Arial", Font.PLAIN, 16));
        lblStuID.setBounds(200, 130, 250, 30);
        contentPane.add(lblStuID);

        JLabel lblSex = new JLabel("Gender:");
        lblSex.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSex.setBounds(50, 170, 100, 30);
        contentPane.add(lblSex);

        lblStuSex = new JLabel();
        lblStuSex.setFont(new Font("Arial", Font.PLAIN, 16));
        lblStuSex.setBounds(200, 170, 250, 30);
        contentPane.add(lblStuSex);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setFont(new Font("Arial", Font.PLAIN, 16));
        lblAge.setBounds(50, 210, 100, 30);
        contentPane.add(lblAge);

        lblStuAge = new JLabel();
        lblStuAge.setFont(new Font("Arial", Font.PLAIN, 16));
        lblStuAge.setBounds(200, 210, 250, 30);
        contentPane.add(lblStuAge);

        JLabel lblDept = new JLabel("Major:");
        lblDept.setFont(new Font("Arial", Font.PLAIN, 16));
        lblDept.setBounds(50, 250, 100, 30);
        contentPane.add(lblDept);

        lblStuDept = new JLabel();
        lblStuDept.setFont(new Font("Arial", Font.PLAIN, 16));
        lblStuDept.setBounds(200, 250, 250, 30);
        contentPane.add(lblStuDept);

        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Arial", Font.PLAIN, 16));
        btnSearch.setBounds(50, 310, 120, 40); // Increased size
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    findStuInfo(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnSearch);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(200, 310, 120, 40);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnReset);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(350, 310, 120, 40);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExit);
    }

    protected void findStuInfo(ActionEvent e) throws SQLException {
        // Retrieve student information
        StudentDao studentDao = new StudentDao();
        String name = this.FindStuName.getText();
        String StuID = studentDao.getId(name);
        String StuAge = studentDao.getAge(name);
        String StuSex = studentDao.getSex(name);
        String StuDept = studentDao.getDept(name);
        this.lblStuID.setText(StuID);
        this.lblStuSex.setText(StuSex);
        this.lblStuDept.setText(StuDept);
        this.lblStuAge.setText(StuAge);
    }

    protected void resetButton(ActionEvent e) {
        // Reset fields
        this.FindStuName.setText("");
        this.lblStuID.setText("");
        this.lblStuSex.setText("");
        this.lblStuDept.setText("");
        this.lblStuAge.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Exit the window
        this.setVisible(false);
    }
}
