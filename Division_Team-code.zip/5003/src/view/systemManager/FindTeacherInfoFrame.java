package view.systemManager;

import dao.TeacherDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class FindTeacherInfoFrame extends JFrame {

    private JPanel contentPane;
    private JTextField TeacherName;
    private JLabel TeacherID;
    private JLabel TeachCourseName;
    private JLabel TeachCourseID;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FindTeacherInfoFrame frame = new FindTeacherInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public FindTeacherInfoFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 550, 400); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Find Teacher Information");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22)); // Increased font size
        lblTitle.setBounds(150, 20, 300, 40); // Adjusted position
        contentPane.add(lblTitle);

        JLabel lblPrompt = new JLabel("Enter Teacher Name to Search:");
        lblPrompt.setFont(new Font("Arial", Font.PLAIN, 16));
        lblPrompt.setBounds(50, 80, 250, 30); // Adjusted position
        contentPane.add(lblPrompt);

        TeacherName = new JTextField();
        TeacherName.setFont(new Font("Arial", Font.PLAIN, 16));
        TeacherName.setBounds(310, 80, 180, 30); // Increased size
        contentPane.add(TeacherName);
        TeacherName.setColumns(10);

        JLabel lblID = new JLabel("Teacher ID:");
        lblID.setFont(new Font("Arial", Font.PLAIN, 16));
        lblID.setBounds(50, 130, 100, 30);
        contentPane.add(lblID);

        TeacherID = new JLabel();
        TeacherID.setFont(new Font("Arial", Font.PLAIN, 16));
        TeacherID.setBounds(200, 130, 250, 30);
        contentPane.add(TeacherID);

        JLabel lblCourseName = new JLabel("Course Name:");
        lblCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        lblCourseName.setBounds(50, 170, 120, 30);
        contentPane.add(lblCourseName);

        TeachCourseName = new JLabel();
        TeachCourseName.setFont(new Font("Arial", Font.PLAIN, 16));
        TeachCourseName.setBounds(200, 170, 250, 30);
        contentPane.add(TeachCourseName);

        JLabel lblCourseID = new JLabel("Course ID:");
        lblCourseID.setFont(new Font("Arial", Font.PLAIN, 16));
        lblCourseID.setBounds(50, 210, 100, 30);
        contentPane.add(lblCourseID);

        TeachCourseID = new JLabel();
        TeachCourseID.setFont(new Font("Arial", Font.PLAIN, 16));
        TeachCourseID.setBounds(200, 210, 250, 30);
        contentPane.add(TeachCourseID);

        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Arial", Font.PLAIN, 16));
        btnSearch.setBounds(50, 280, 120, 40); // Increased size
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    find(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnSearch);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(200, 280, 120, 40);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnReset);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(350, 280, 120, 40);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExit);
    }

    protected void find(ActionEvent e) throws SQLException {
        // Retrieve teacher information
        TeacherDao teacherDao = new TeacherDao();
        String teacherName = this.TeacherName.getText();
        this.TeacherID.setText(teacherDao.getId(teacherName));
        this.TeachCourseID.setText(teacherDao.getTeachCourseID(teacherName));
        this.TeachCourseName.setText(teacherDao.getTeachCourse(teacherName));
    }

    protected void resetButton(ActionEvent e) {
        // Reset fields
        this.TeacherName.setText("");
        this.TeachCourseID.setText("");
        this.TeachCourseName.setText("");
        this.TeacherID.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Exit the window
        this.dispose();
    }
}
