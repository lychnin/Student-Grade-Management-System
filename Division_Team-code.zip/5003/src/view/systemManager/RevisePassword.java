package view.systemManager;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Font;
import java.awt.Color;

import dao.AdminDao;
import dao.StudentDao;
import util.StrUtil;
import view.IndexFrame;
import view.StudentFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RevisePassword extends JInternalFrame {
    private JTextField oldPasswordText;
    private JTextField newPasswordText;
    private JTextField againPasswordText;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    RevisePassword frame = new RevisePassword();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    // Password modification method for administrators
    public RevisePassword() {
        setBounds(100, 100, 500, 350); // Adjusted frame size

        getContentPane().setLayout(null);
        setClosable(true);
        JLabel lblNewLabel = new JLabel("Current User");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size
        lblNewLabel.setBounds(70, 30, 150, 25);
        getContentPane().add(lblNewLabel);

        String userTypeStr = IndexFrame.userType.getName();
        String adminNameStr = IndexFrame.admin.getName();

        JLabel lbladmin = new JLabel("[" + userTypeStr + "] " + adminNameStr);
        lbladmin.setForeground(new Color(255, 0, 0));
        lbladmin.setFont(new Font("Arial", Font.BOLD, 16));
        lbladmin.setBounds(200, 30, 250, 25); // Adjusted position
        getContentPane().add(lbladmin);

        JLabel lblOldPassword = new JLabel("Old Password:");
        lblOldPassword.setFont(new Font("Arial", Font.BOLD, 16));
        lblOldPassword.setBounds(70, 80, 150, 30);
        getContentPane().add(lblOldPassword);

        JLabel lblNewPassword = new JLabel("New Password:");
        lblNewPassword.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewPassword.setBounds(70, 130, 150, 30);
        getContentPane().add(lblNewPassword);

        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setFont(new Font("Arial", Font.BOLD, 16));
        lblConfirmPassword.setBounds(70, 180, 200, 30);
        getContentPane().add(lblConfirmPassword);

        oldPasswordText = new JTextField();
        oldPasswordText.setFont(new Font("Arial", Font.PLAIN, 16));
        oldPasswordText.setBounds(250, 80, 200, 30); // Increased size
        getContentPane().add(oldPasswordText);

        newPasswordText = new JTextField();
        newPasswordText.setFont(new Font("Arial", Font.PLAIN, 16));
        newPasswordText.setBounds(250, 130, 200, 30); // Increased size
        getContentPane().add(newPasswordText);

        againPasswordText = new JTextField();
        againPasswordText.setFont(new Font("Arial", Font.PLAIN, 16));
        againPasswordText.setBounds(250, 180, 200, 30); // Increased size
        getContentPane().add(againPasswordText);

        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.setFont(new Font("Arial", Font.PLAIN, 16));
        btnConfirm.setBounds(70, 250, 120, 40); // Increased size
        btnConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                confirmButton(e);
            }
        });
        getContentPane().add(btnConfirm);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(200, 250, 120, 40);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        getContentPane().add(btnReset);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(330, 250, 120, 40);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the window
            }
        });
        getContentPane().add(btnExit);

        setVisible(true);
    }

    // Confirm button for password modification
    protected void confirmButton(ActionEvent e) {
        String oldPassword = this.oldPasswordText.getText();
        String newPassword = this.newPasswordText.getText();
        String againPassword = this.againPasswordText.getText();
        if (StrUtil.isEmpty(oldPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the old password");
            return;
        }
        if (StrUtil.isEmpty(newPassword)) {
            JOptionPane.showMessageDialog(this, "Please enter the new password");
            return;
        }
        if (StrUtil.isEmpty(againPassword)) {
            JOptionPane.showMessageDialog(this, "Please confirm the new password");
            return;
        }
        if (!newPassword.equals(againPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match");
            return;
        }
        if ("System Administrator".equals(IndexFrame.userType.getName())) {
            AdminDao adminDao = new AdminDao();
            JOptionPane.showMessageDialog(this, adminDao.revisePassword(String.valueOf(IndexFrame.admin), newPassword));
            resetButton(e);
            return;
        }
        if ("Student".equals(IndexFrame.userType.getName())) {
            StudentDao studentDao = new StudentDao();
            JOptionPane.showMessageDialog(this, studentDao.revisePassword(String.valueOf(StudentFrame.student), newPassword));
            resetButton(e);
            return;
        }
        if ("Teacher".equals(IndexFrame.userType.getName())) {
            JOptionPane.showMessageDialog(this, "Password modification for teachers is not supported yet.");
            return;
        }
    }

    // Reset button for password modification
    protected void resetButton(ActionEvent e) {
        this.oldPasswordText.setText("");
        this.newPasswordText.setText("");
        this.againPasswordText.setText("");
    }
}
