package view.systemManager;

import dao.StudentDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class ReviseStuInfoFrame extends JFrame {

    private JPanel contentPane;
    private JTextField ChangeStuSex;
    private JTextField ChangeStuAge;
    private JTextField ChangeStuDept;
    private JTextField ChangeStuPassword;
    private JTextField Changewho;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ReviseStuInfoFrame frame = new ReviseStuInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public ReviseStuInfoFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 550, 400); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Revise Student Information");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22)); // Increased font size
        lblTitle.setBounds(150, 20, 300, 30);
        contentPane.add(lblTitle);

        JLabel lblWho = new JLabel("Enter Student Name to Modify:");
        lblWho.setFont(new Font("Arial", Font.PLAIN, 16));
        lblWho.setBounds(20, 70, 250, 30);
        contentPane.add(lblWho);

        Changewho = new JTextField();
        Changewho.setFont(new Font("Arial", Font.PLAIN, 16));
        Changewho.setBounds(280, 70, 200, 30); // Increased size
        contentPane.add(Changewho);

        JLabel lblModify = new JLabel("After Modification:");
        lblModify.setFont(new Font("Arial", Font.BOLD, 16));
        lblModify.setBounds(20, 110, 200, 30);
        contentPane.add(lblModify);

        JLabel lblSex = new JLabel("Gender:");
        lblSex.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSex.setBounds(50, 150, 100, 30);
        contentPane.add(lblSex);

        ChangeStuSex = new JTextField();
        ChangeStuSex.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeStuSex.setBounds(200, 150, 280, 30); // Increased size
        contentPane.add(ChangeStuSex);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setFont(new Font("Arial", Font.PLAIN, 16));
        lblAge.setBounds(50, 190, 100, 30);
        contentPane.add(lblAge);

        ChangeStuAge = new JTextField();
        ChangeStuAge.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeStuAge.setBounds(200, 190, 280, 30); // Increased size
        contentPane.add(ChangeStuAge);

        JLabel lblDept = new JLabel("Major:");
        lblDept.setFont(new Font("Arial", Font.PLAIN, 16));
        lblDept.setBounds(50, 230, 100, 30);
        contentPane.add(lblDept);

        ChangeStuDept = new JTextField();
        ChangeStuDept.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeStuDept.setBounds(200, 230, 280, 30); // Increased size
        contentPane.add(ChangeStuDept);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        lblPassword.setBounds(50, 270, 100, 30);
        contentPane.add(lblPassword);

        ChangeStuPassword = new JTextField();
        ChangeStuPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeStuPassword.setBounds(200, 270, 280, 30); // Increased size
        contentPane.add(ChangeStuPassword);

        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.setFont(new Font("Arial", Font.PLAIN, 16));
        btnConfirm.setBounds(60, 320, 120, 40); // Increased size
        btnConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    confirmButton(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnConfirm);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(220, 320, 120, 40); // Increased size
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnReset);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(380, 320, 120, 40); // Increased size
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExit);
    }

    protected void confirmButton(ActionEvent e) throws SQLException {
        // Confirm button to update student information
        StudentDao studentDao = new StudentDao();
        String ChangeWho = this.Changewho.getText();
        String StuSex = this.ChangeStuSex.getText();
        int StuAge = Integer.parseInt(this.ChangeStuAge.getText());
        String StuDept = this.ChangeStuDept.getText();
        String StuPassword = this.ChangeStuPassword.getText();
        String result = studentDao.reviseStuInfo(ChangeWho, StuSex, StuAge, StuDept, StuPassword);
        JOptionPane.showMessageDialog(this, result);
        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        // Reset input fields
        this.Changewho.setText("");
        this.ChangeStuAge.setText("");
        this.ChangeStuDept.setText("");
        this.ChangeStuSex.setText("");
        this.ChangeStuPassword.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Close the window
        this.dispose();
    }
}
