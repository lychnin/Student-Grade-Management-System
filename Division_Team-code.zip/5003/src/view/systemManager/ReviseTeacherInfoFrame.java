package view.systemManager;

import dao.TeacherDao;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class ReviseTeacherInfoFrame extends JFrame {

    private JPanel contentPane;
    private JTextField TeacherName;
    private JTextField ChangeTeacherCourse;
    private JTextField ChangeTeachID;
    private JTextField ChangeTeacherPassword;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ReviseTeacherInfoFrame frame = new ReviseTeacherInfoFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public ReviseTeacherInfoFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 550, 400); // Increased frame size
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10)); // Added padding
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblTitle = new JLabel("Revise Teacher Information");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setBounds(140, 20, 300, 30);
        contentPane.add(lblTitle);

        JLabel lblNewLabel_1_2 = new JLabel("Enter Teacher Name to Modify:");
        lblNewLabel_1_2.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_2.setBounds(20, 70, 250, 30);
        contentPane.add(lblNewLabel_1_2);

        TeacherName = new JTextField();
        TeacherName.setFont(new Font("Arial", Font.PLAIN, 16));
        TeacherName.setBounds(280, 70, 200, 30);
        contentPane.add(TeacherName);

        JLabel lblNewLabel_2 = new JLabel("After Modification:");
        lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel_2.setBounds(20, 110, 200, 30);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_1_1_1 = new JLabel("Course Name:");
        lblNewLabel_1_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1_1.setBounds(50, 150, 120, 30);
        contentPane.add(lblNewLabel_1_1_1);

        ChangeTeacherCourse = new JTextField();
        ChangeTeacherCourse.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeTeacherCourse.setBounds(200, 150, 280, 30);
        contentPane.add(ChangeTeacherCourse);

        JLabel lblNewLabel_1_1_1_1 = new JLabel("Course ID:");
        lblNewLabel_1_1_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1_1_1.setBounds(50, 190, 120, 30);
        contentPane.add(lblNewLabel_1_1_1_1);

        ChangeTeachID = new JTextField();
        ChangeTeachID.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeTeachID.setBounds(200, 190, 280, 30);
        contentPane.add(ChangeTeachID);

        JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Password:");
        lblNewLabel_1_1_1_1_1_1.setFont(new Font("Arial", Font.PLAIN, 16));
        lblNewLabel_1_1_1_1_1_1.setBounds(50, 230, 120, 30);
        contentPane.add(lblNewLabel_1_1_1_1_1_1);

        ChangeTeacherPassword = new JTextField();
        ChangeTeacherPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        ChangeTeacherPassword.setBounds(200, 230, 280, 30);
        contentPane.add(ChangeTeacherPassword);

        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.setFont(new Font("Arial", Font.PLAIN, 16));
        btnConfirm.setBounds(50, 300, 120, 40);
        btnConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    confirmButton(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnConfirm);

        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.PLAIN, 16));
        btnReset.setBounds(210, 300, 120, 40);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetButton(e);
            }
        });
        contentPane.add(btnReset);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 16));
        btnExit.setBounds(370, 300, 120, 40);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButton(e);
            }
        });
        contentPane.add(btnExit);
    }

    protected void confirmButton(ActionEvent e) throws SQLException {
        // Confirm button to update teacher information
        TeacherDao teacherDao = new TeacherDao();
        String teacherName = this.TeacherName.getText();
        String courseName = this.ChangeTeacherCourse.getText();
        int courseID = Integer.parseInt(this.ChangeTeachID.getText());
        String password = this.ChangeTeacherPassword.getText();
        String result = teacherDao.reviseTeacherInfo(teacherName, courseName, courseID, password);
        JOptionPane.showMessageDialog(this, result);
        this.resetButton(e);
    }

    protected void resetButton(ActionEvent e) {
        // Reset input fields
        this.ChangeTeacherCourse.setText("");
        this.TeacherName.setText("");
        this.ChangeTeacherPassword.setText("");
        this.ChangeTeachID.setText("");
    }

    protected void exitButton(ActionEvent e) {
        // Close the window
        this.dispose();
    }
}
