# Student Information Management System

## Overview
This is a Java-based desktop application for managing student information. The application uses SQLite as the database and requires the database file path to be provided as a command-line argument during runtime.

---

## Requirements

### Operating System
- macOS 14.5 or later

### Software
- **Java Development Kit (JDK)**: OpenJDK 1.8 or later
- **SQLite JDBC Driver**: `sqlite-jdbc-3.47.1.0.jar` (included in the project dependencies)
- **Development IDE**: IntelliJ IDEA (Ultimate or Community Edition)

### Dependencies
- SQLite database file (`.db`): Required at runtime.

---

## How to Compile

1. **Open the project**:
   - Import the project into IntelliJ IDEA.

2. **Add dependencies**:
   - Ensure the SQLite JDBC driver (`sqlite-jdbc-3.47.1.0.jar`) is included in your project dependencies:
     - Go to `File > Project Structure > Artifacts` and add the JAR file.

3. **Build the project**:
   - Navigate to `Build > Build Artifacts > Build`.
   - The generated JAR file will be located in the `out/artifacts` directory.

---

## How to Run

1. Open the terminal and navigate to the directory where the JAR file is located.
2. Run the application with the following command:
   ```bash
   java -jar StudentInformationManagementSystem.jar <path-to-your-database>
   ```
   Replace `<path-to-your-database>` with the absolute path to your SQLite database file. For example:
   ```bash
   java -jar StudentInformationManagementSystem.jar /Users/du/Desktop/studentManagementSystem.db
   ```

3. The GUI application will launch. You can log in and interact with the system.

---

## Notes

1. **Database Path**:
   - The database path must be provided as a command-line argument. If the path is missing, the application will terminate with an error message:
     ```
     Usage: java -jar StudentInformationManagementSystem.jar <path-to-your-local-db-file>
     ```

2. **Database Initialization**:
   - The application dynamically initializes the database connection using the provided path. Ensure the path points to a valid SQLite `.db` file.

3. **Environment**:
   - Ensure the deployment environment has OpenJDK installed and properly configured.

---

## Example Usage

```bash
java -jar StudentInformationManagementSystem.jar /Users/du/Desktop/studentManagementSystem.db
```

This command launches the application using the `studentManagementSystem.db` file located on the Desktop.

---

## Common Issues

1. **SQLite Driver Not Found**:
   - Ensure the SQLite JDBC driver is included in your project and packaged correctly in the JAR file.

2. **Invalid Database Path**:
   - Double-check the provided database path. It must point to a valid SQLite file.

3. **Java Not Found**:
   - Verify that Java is installed on your system by running:
     ```bash
     java -version
     ```

---

## Author
Developed by Division Team. Feel free to reach out for any questions or issues.
